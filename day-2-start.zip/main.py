num_char = len(input("What is your Name?"))
print("Your name has " + str(num_char) + " characters")