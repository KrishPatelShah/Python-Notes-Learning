for x in range(20, 3,-7):
  print(x) 