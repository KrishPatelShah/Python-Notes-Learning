print("Welcome to the Band Name Generator.")
city = input("What city did you grow up in?\n")
petName = input("Name of Pet?\n")
print(city + " " + petName)